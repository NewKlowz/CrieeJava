package AllSee;

public class Affichage {

	public Affichage() {
		// TODO Auto-generated constructor stub
	}

}
