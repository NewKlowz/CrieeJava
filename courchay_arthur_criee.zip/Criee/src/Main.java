
public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

}
